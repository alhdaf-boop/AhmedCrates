package com.ahmedcrates;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public final class AhmedCrates extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<String, Crate> crates = new LinkedHashMap<>();
    private final Map<UUID, String> placing = new HashMap<>();
    private final Map<UUID, String> editing = new HashMap<>();
    private final Map<UUID, String> previewing = new HashMap<>();

    private static final class Crate {
        String id, display, shulker;
        String world;
        int x, y, z;
        List<ItemStack> rewards = new ArrayList<>();
        Crate(String id) { this.id = id; this.display = id; this.shulker = "GREEN_SHULKER_BOX"; }
        boolean hasBlock() { return world != null; }
    }

    @Override public void onEnable() {
        saveDefaultConfig();
        loadCrates();
        Objects.requireNonNull(getCommand("crate")).setExecutor(this);
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("AhmedCrates enabled.");
    }

    @Override public void onDisable() { saveCrates(); }

    private void loadCrates() {
        ConfigurationSection root = getConfig().getConfigurationSection("crates");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;
            Crate c = new Crate(id);
            c.display = s.getString("display", id);
            c.shulker = s.getString("shulker", "GREEN_SHULKER_BOX");
            c.world = s.getString("world");
            c.x = s.getInt("x"); c.y = s.getInt("y"); c.z = s.getInt("z");
            for (Object o : s.getList("rewards", List.of())) if (o instanceof ItemStack item) c.rewards.add(item.clone());
            crates.put(id, c);
        }
    }

    private void saveCrates() {
        getConfig().set("crates", null);
        for (Crate c : crates.values()) {
            String p = "crates." + c.id + ".";
            getConfig().set(p + "display", c.display);
            getConfig().set(p + "shulker", c.shulker);
            getConfig().set(p + "world", c.world);
            getConfig().set(p + "x", c.x); getConfig().set(p + "y", c.y); getConfig().set(p + "z", c.z);
            getConfig().set(p + "rewards", c.rewards);
        }
        saveConfig();
    }

    private String keyPath(String crate, UUID player) { return "keys." + player + "." + crate; }
    private int keys(String crate, UUID player) { return Math.max(0, getConfig().getInt(keyPath(crate, player), 0)); }
    private void setKeys(String crate, UUID player, int amount) { getConfig().set(keyPath(crate, player), Math.max(0, amount)); saveConfig(); }

    private ItemStack icon(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(ChatColor.RESET + name);
        if (lore.length > 0) meta.setLore(Arrays.asList(lore));
        it.setItemMeta(meta);
        return it;
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] a) {
        if (a.length == 0) {
            sender.sendMessage(ChatColor.GOLD + "AhmedCrates commands:");
            sender.sendMessage(ChatColor.YELLOW + "/crate create <id>");
            sender.sendMessage(ChatColor.YELLOW + "/crate edit <id>");
            sender.sendMessage(ChatColor.YELLOW + "/crate key give|take <player> <crate> <amount>");
            sender.sendMessage(ChatColor.YELLOW + "/crate list");
            sender.sendMessage(ChatColor.YELLOW + "/crate remove <id>");
            return true;
        }
        if (a[0].equalsIgnoreCase("list")) {
            if (crates.isEmpty()) sender.sendMessage("No crates created.");
            else crates.keySet().forEach(id -> sender.sendMessage(ChatColor.GREEN + id + ChatColor.GRAY + " - " + crates.get(id).display));
            return true;
        }
        if (!(sender instanceof Player p) || !p.hasPermission("ahmedcrates.admin")) {
            if (!(sender instanceof Player)) sender.sendMessage("This command requires a player with admin permission.");
            else sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }
        if (a[0].equalsIgnoreCase("create") && a.length >= 2) {
            String id = a[1].toLowerCase(Locale.ROOT);
            if (!id.matches("[a-z0-9_-]{1,24}") || crates.containsKey(id)) {
                p.sendMessage(ChatColor.RED + "Invalid or existing crate ID."); return true;
            }
            Crate c = new Crate(id); crates.put(id, c); saveCrates();
            openCreateMenu(p, c);
            return true;
        }
        if (a[0].equalsIgnoreCase("edit") && a.length >= 2) {
            Crate c = crates.get(a[1].toLowerCase(Locale.ROOT));
            if (c == null) { p.sendMessage(ChatColor.RED + "Crate not found."); return true; }
            openEditor(p, c); return true;
        }
        if (a[0].equalsIgnoreCase("remove") && a.length >= 2) {
            Crate c = crates.remove(a[1].toLowerCase(Locale.ROOT));
            if (c == null) p.sendMessage(ChatColor.RED + "Crate not found.");
            else { saveCrates(); p.sendMessage(ChatColor.GREEN + "Crate removed."); }
            return true;
        }
        if (a[0].equalsIgnoreCase("key") && a.length == 5) {
            Player target = Bukkit.getPlayerExact(a[2]);
            Crate c = crates.get(a[3].toLowerCase(Locale.ROOT));
            int amount;
            try { amount = Integer.parseInt(a[4]); } catch (NumberFormatException ex) { amount = -1; }
            if (target == null || c == null || amount < 1) { p.sendMessage(ChatColor.RED + "Usage: /crate key give|take <online-player> <crate> <amount>"); return true; }
            int old = keys(c.id, target.getUniqueId());
            if (a[1].equalsIgnoreCase("give")) setKeys(c.id, target.getUniqueId(), old + amount);
            else if (a[1].equalsIgnoreCase("take")) setKeys(c.id, target.getUniqueId(), Math.max(0, old - amount));
            else { p.sendMessage(ChatColor.RED + "Use give or take."); return true; }
            p.sendMessage(ChatColor.GREEN + "Key balance updated for " + target.getName() + ".");
            return true;
        }
        p.sendMessage(ChatColor.RED + "Unknown command. Use /crate");
        return true;
    }

    private void openCreateMenu(Player p, Crate c) {
        Inventory inv = Bukkit.createInventory(null, 27, "Create crate: " + c.id);
        inv.setItem(13, icon(Material.ENDER_CHEST, "Drop a Shulker Box here", "It will be returned to you.", "Then place that Shulker Box in the world."));
        p.openInventory(inv);
    }

    private void openEditor(Player p, Crate c) {
        Inventory inv = Bukkit.createInventory(null, 27, "Rewards: " + c.id);
        for (int i = 0; i < Math.min(27, c.rewards.size()); i++) inv.setItem(i, c.rewards.get(i).clone());
        editing.put(p.getUniqueId(), c.id);
        p.openInventory(inv);
    }

    private void openPreview(Player p, Crate c) {
        Inventory inv = Bukkit.createInventory(null, 27, "Rewards: " + c.display);
        for (int i = 0; i < Math.min(27, c.rewards.size()); i++) inv.setItem(i, c.rewards.get(i).clone());
        previewing.put(p.getUniqueId(), c.id);
        p.openInventory(inv);
    }

    @EventHandler(ignoreCancelled = true)
    public void onCreateClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String title = e.getView().getTitle();
        if (title.startsWith("Create crate: ")) {
            e.setCancelled(true);
            if (e.getRawSlot() != 13 || e.getCursor() == null || e.getCursor().getType().isAir()) return;
            Material m = e.getCursor().getType();
            if (!m.name().endsWith("_SHULKER_BOX")) { p.sendMessage(ChatColor.RED + "Please use a Shulker Box."); return; }
            String id = title.substring("Create crate: ".length());
            Crate c = crates.get(id);
            if (c == null) return;
            c.shulker = m.name();
            ItemStack returned = e.getCursor().clone();
            e.setCursor(null);
            Map<Integer, ItemStack> leftovers = p.getInventory().addItem(returned);
            leftovers.values().forEach(item -> p.getWorld().dropItemNaturally(p.getLocation(), item));
            placing.put(p.getUniqueId(), id);
            p.closeInventory();
            p.sendMessage(ChatColor.GREEN + "Shulker returned. Place it where the crate should be.");
            saveCrates();
            return;
        }
        String editId = editing.get(p.getUniqueId());
        if (editId != null && title.equals("Rewards: " + editId)) {
            if (e.getClickedInventory() == e.getView().getTopInventory()) return;
            // Let admins move items from their inventory into the reward editor.
            return;
        }
        String previewId = previewing.get(p.getUniqueId());
        if (previewId != null && title.startsWith("Rewards: ")) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (previewing.containsKey(p.getUniqueId())) { e.setCancelled(true); return; }
        String id = editing.get(p.getUniqueId());
        if (id != null && e.getView().getTitle().equals("Rewards: " + id)) {
            for (int slot : e.getRawSlots()) if (slot < 27) return;
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;
        String id = editing.remove(p.getUniqueId());
        if (id != null && e.getView().getTitle().equals("Rewards: " + id)) {
            Crate c = crates.get(id);
            if (c != null) {
                c.rewards.clear();
                for (ItemStack it : e.getView().getTopInventory().getContents())
                    if (it != null && !it.getType().isAir()) c.rewards.add(it.clone());
                saveCrates();
                p.sendMessage(ChatColor.GREEN + "Crate rewards saved.");
            }
        }
        previewing.remove(p.getUniqueId());
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        String id = placing.get(p.getUniqueId());
        if (id == null) return;
        Crate c = crates.get(id);
        if (c == null) { placing.remove(p.getUniqueId()); return; }
        if (!e.getBlockPlaced().getType().name().equals(c.shulker)) {
            e.setCancelled(true); p.sendMessage(ChatColor.RED + "Place the Shulker Box selected for this crate."); return;
        }
        Block b = e.getBlockPlaced();
        c.world = b.getWorld().getName(); c.x = b.getX(); c.y = b.getY(); c.z = b.getZ();
        placing.remove(p.getUniqueId());
        saveCrates();
        p.sendMessage(ChatColor.GREEN + "Crate " + id + " linked successfully!");
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if ((e.getAction() != Action.RIGHT_CLICK_BLOCK && e.getAction() != Action.LEFT_CLICK_BLOCK) || e.getClickedBlock() == null) return;
        Block b = e.getClickedBlock();
        for (Crate c : crates.values()) {
            if (c.hasBlock() && c.world.equals(b.getWorld().getName()) && c.x == b.getX() && c.y == b.getY() && c.z == b.getZ()) {
                e.setCancelled(true);
                Player p = e.getPlayer();
                if (e.getAction() == Action.RIGHT_CLICK_BLOCK && keys(c.id, p.getUniqueId()) <= 0) {
                    p.sendMessage(ChatColor.RED + "You need a key to open this crate!");
                    return;
                }
                openPreview(p, c);
                return;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onClaim(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String id = previewing.get(p.getUniqueId());
        if (id == null || !e.getView().getTitle().startsWith("Rewards: ")) return;
        e.setCancelled(true);
        if (e.getRawSlot() < 0 || e.getRawSlot() >= 27) return;
        Crate c = crates.get(id);
        if (c == null || e.getRawSlot() >= c.rewards.size()) return;
        if (keys(id, p.getUniqueId()) <= 0) { p.sendMessage(ChatColor.RED + "You need a key to open this crate!"); return; }
        ItemStack reward = c.rewards.get(e.getRawSlot()).clone();
        if (!canFit(p.getInventory(), reward)) {
            p.sendMessage(ChatColor.RED + "Your inventory is full!");
            return;
        }
        setKeys(id, p.getUniqueId(), keys(id, p.getUniqueId()) - 1);
        p.getInventory().addItem(reward);
        p.sendMessage(ChatColor.GREEN + "Reward claimed!");
        if (keys(id, p.getUniqueId()) <= 0) p.closeInventory();
    }

    private boolean canFit(PlayerInventory inv, ItemStack item) {
        int remaining = item.getAmount();
        for (ItemStack slot : inv.getStorageContents()) {
            if (slot == null || slot.getType().isAir()) remaining -= item.getMaxStackSize();
            else if (slot.isSimilar(item)) remaining -= Math.max(0, slot.getMaxStackSize() - slot.getAmount());
            if (remaining <= 0) return true;
        }
        return remaining <= 0;
    }

    @EventHandler public void onQuit(PlayerQuitEvent e) {
        placing.remove(e.getPlayer().getUniqueId());
        editing.remove(e.getPlayer().getUniqueId());
        previewing.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        for (Crate c : crates.values()) {
            if (c.hasBlock() && c.world.equals(e.getBlock().getWorld().getName()) &&
                c.x == e.getBlock().getX() && c.y == e.getBlock().getY() && c.z == e.getBlock().getZ()) {
                if (!e.getPlayer().hasPermission("ahmedcrates.admin")) {
                    e.setCancelled(true);
                    e.getPlayer().sendMessage(ChatColor.RED + "This crate is protected.");
                } else {
                    c.world = null; saveCrates();
                }
                return;
            }
        }
    }
}
